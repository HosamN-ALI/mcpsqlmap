"""Integration with external services (LangChain, Open WebUI, Deepseek)"""
