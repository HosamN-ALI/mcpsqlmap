import pytest
import os
import logging
from typing import Dict, Any

# Configure logging for tests
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

@pytest.fixture(scope="session")
def api_key() -> str:
    """Provide Deepseek API key for tests"""
    return "sk-1bd5de3f31db429cb8cbe73875537c5c"

@pytest.fixture(scope="session")
def test_config() -> Dict[str, Any]:
    """Provide test configuration"""
    return {
        "server": {
            "host": "localhost",
            "port": 8000,
            "debug": True
        },
        "deepseek": {
            "api_url": "https://api.deepseek.com/v1",
            "timeout": 30
        },
        "injection": {
            "max_retries": 3,
            "timeout": 10
        },
        "waf_bypass": {
            "max_attempts": 5,
            "delay": 1
        },
        "payloads": {
            "max_size": 1000,
            "cache_duration": 3600
        }
    }

@pytest.fixture(scope="session")
def sample_payloads() -> Dict[str, str]:
    """Provide sample payloads for testing"""
    return {
        "union": "' UNION SELECT NULL,NULL,NULL--",
        "blind": "' AND SLEEP(5)--",
        "error": "' AND EXTRACTVALUE(1,CONCAT(0x7e,VERSION()))--",
        "stacked": "'; DROP TABLE users--",
        "stored_proc": "'; EXEC xp_cmdshell 'net user'--",
        "nosql": '{"$ne": null}'
    }

@pytest.fixture(scope="session")
def sample_targets() -> Dict[str, str]:
    """Provide sample target URLs for testing"""
    return {
        "mysql": "http://example.com/mysql_vuln.php",
        "mssql": "http://example.com/mssql_vuln.asp",
        "postgres": "http://example.com/pg_vuln.php",
        "nosql": "http://example.com/mongo_vuln.js"
    }

@pytest.fixture(scope="function")
async def mock_deepseek_response() -> Dict[str, Any]:
    """Provide mock Deepseek API response"""
    return {
        "analysis": {
            "vulnerability_type": "sql_injection",
            "risk_level": "high",
            "explanation": "The query is vulnerable to SQL injection",
            "mitigation": "Use prepared statements",
            "exploit_scenario": "An attacker could bypass authentication",
            "bypass_techniques": [
                {
                    "name": "case_randomization",
                    "effectiveness": "high"
                },
                {
                    "name": "comment_injection",
                    "effectiveness": "medium"
                }
            ],
            "recommended_payload": "SeLeCt/**/*/**/FrOm/**/users"
        }
    }

@pytest.fixture(scope="function")
def temp_test_dir(tmp_path):
    """Provide temporary directory for test files"""
    test_dir = tmp_path / "test_files"
    test_dir.mkdir()
    return test_dir

@pytest.fixture(autouse=True)
def cleanup_after_test():
    """Cleanup after each test"""
    yield
    # Add any cleanup logic here if needed

def pytest_configure(config):
    """Configure pytest"""
    config.addinivalue_line(
        "markers",
        "integration: mark test as integration test"
    )
    config.addinivalue_line(
        "markers",
        "slow: mark test as slow running"
    )

def pytest_collection_modifyitems(config, items):
    """Modify test items based on markers"""
    if not config.getoption("--run-slow"):
        skip_slow = pytest.mark.skip(reason="need --run-slow option to run")
        for item in items:
            if "slow" in item.keywords:
                item.add_marker(skip_slow)

def pytest_addoption(parser):
    """Add custom command line options"""
    parser.addoption(
        "--run-slow",
        action="store_true",
        default=False,
        help="run slow tests"
    )
    parser.addoption(
        "--integration",
        action="store_true",
        default=False,
        help="run integration tests"
    )
