"""Test suite for MCP Server components"""
