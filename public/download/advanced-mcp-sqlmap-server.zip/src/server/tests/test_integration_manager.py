import pytest
from unittest.mock import Mock, patch, AsyncMock
from ..integrations.integration_manager import (
    IntegrationManager,
    IntegrationType,
    IntegrationResult
)

@pytest.fixture
async def integration_manager():
    manager = IntegrationManager(api_key="sk-1bd5de3f31db429cb8cbe73875537c5c")
    await manager.initialize()
    return manager

@pytest.mark.asyncio
async def test_initialization():
    """Test IntegrationManager initialization"""
    manager = IntegrationManager(api_key="sk-1bd5de3f31db429cb8cbe73875537c5c")
    result = await manager.initialize()
    
    assert isinstance(result, IntegrationResult)
    assert result.success is True
    assert manager.webui_session is not None

@pytest.mark.asyncio
async def test_initialization_no_api_key():
    """Test initialization without API key"""
    manager = IntegrationManager()
    result = await manager.initialize()
    
    assert isinstance(result, IntegrationResult)
    assert result.success is False
    assert "API key required" in result.error

@pytest.mark.asyncio
async def test_deepseek_analysis_success(integration_manager):
    """Test successful Deepseek API analysis"""
    data = {
        "type": "vulnerability_analysis",
        "query": "SELECT * FROM users WHERE id = '" + user_input + "'",
        "context": {
            "database_type": "mysql",
            "user_input": "1' OR '1'='1"
        }
    }
    
    mock_response = {
        "choices": [{
            "message": {
                "content": "Analysis: This query is vulnerable to SQL injection..."
            }
        }]
    }
    
    with patch('aiohttp.ClientSession.post') as mock_post:
        mock_context = AsyncMock()
        mock_context.__aenter__.return_value.status = 200
        mock_context.__aenter__.return_value.json = AsyncMock(
            return_value=mock_response
        )
        mock_post.return_value = mock_context
        
        result = await integration_manager.analyze_with_deepseek(data)
        
        assert result.success is True
        assert result.data == mock_response
        
        # Verify API call
        mock_post.assert_called_once()
        call_kwargs = mock_post.call_args[1]
        assert "headers" in call_kwargs
        assert call_kwargs["headers"]["Authorization"] == f"Bearer {integration_manager.api_key}"

@pytest.mark.asyncio
async def test_deepseek_analysis_error(integration_manager):
    """Test Deepseek API error handling"""
    data = {"query": "SELECT * FROM users"}
    
    with patch('aiohttp.ClientSession.post') as mock_post:
        mock_context = AsyncMock()
        mock_context.__aenter__.return_value.status = 401
        mock_context.__aenter__.return_value.text = AsyncMock(
            return_value="Invalid API key"
        )
        mock_post.return_value = mock_context
        
        result = await integration_manager.analyze_with_deepseek(data)
        
        assert result.success is False
        assert "Deepseek API error" in result.error

@pytest.mark.asyncio
async def test_analyze_vulnerability(integration_manager):
    """Test vulnerability analysis"""
    data = {
        "query": "SELECT * FROM users WHERE id = 1",
        "context": {"type": "mysql"}
    }
    
    mock_response = {
        "choices": [{
            "message": {
                "content": "Vulnerability analysis result"
            }
        }]
    }
    
    with patch('aiohttp.ClientSession.post') as mock_post:
        mock_context = AsyncMock()
        mock_context.__aenter__.return_value.status = 200
        mock_context.__aenter__.return_value.json = AsyncMock(
            return_value=mock_response
        )
        mock_post.return_value = mock_context
        
        result = await integration_manager.analyze_vulnerability(data)
        
        assert result["success"] is True
        assert "analysis" in result

@pytest.mark.asyncio
async def test_analyze_payload(integration_manager):
    """Test payload analysis"""
    payload = "' OR '1'='1"
    
    mock_response = {
        "choices": [{
            "message": {
                "content": "Payload analysis result"
            }
        }]
    }
    
    with patch('aiohttp.ClientSession.post') as mock_post:
        mock_context = AsyncMock()
        mock_context.__aenter__.return_value.status = 200
        mock_context.__aenter__.return_value.json = AsyncMock(
            return_value=mock_response
        )
        mock_post.return_value = mock_context
        
        result = await integration_manager.analyze_payload(payload)
        
        assert result["success"] is True
        assert "analysis" in result

@pytest.mark.asyncio
async def test_analyze_waf_bypass(integration_manager):
    """Test WAF bypass analysis"""
    data = {
        "payload": "SELECT * FROM users",
        "waf_type": "modsecurity"
    }
    
    mock_response = {
        "choices": [{
            "message": {
                "content": "WAF bypass analysis result"
            }
        }]
    }
    
    with patch('aiohttp.ClientSession.post') as mock_post:
        mock_context = AsyncMock()
        mock_context.__aenter__.return_value.status = 200
        mock_context.__aenter__.return_value.json = AsyncMock(
            return_value=mock_response
        )
        mock_post.return_value = mock_context
        
        result = await integration_manager.analyze_waf_bypass(data)
        
        assert result["success"] is True
        assert "analysis" in result

@pytest.mark.asyncio
async def test_webui_update_success(integration_manager):
    """Test successful WebUI update"""
    update_data = {
        "status": "scanning",
        "progress": 50,
        "findings": ["SQL injection vulnerability found"]
    }
    
    with patch('aiohttp.ClientSession.post') as mock_post:
        mock_context = AsyncMock()
        mock_context.__aenter__.return_value.status = 200
        mock_context.__aenter__.return_value.json = AsyncMock(
            return_value={"status": "updated"}
        )
        mock_post.return_value = mock_context
        
        result = await integration_manager.update_webui(update_data)
        
        assert result.success is True
        assert result.data["status"] == "updated"

@pytest.mark.asyncio
async def test_webui_update_error(integration_manager):
    """Test WebUI update error handling"""
    update_data = {"status": "error"}
    
    with patch('aiohttp.ClientSession.post') as mock_post:
        mock_context = AsyncMock()
        mock_context.__aenter__.return_value.status = 500
        mock_context.__aenter__.return_value.text = AsyncMock(
            return_value="Internal server error"
        )
        mock_post.return_value = mock_context
        
        result = await integration_manager.update_webui(update_data)
        
        assert result.success is False
        assert "WebUI update failed" in result.error

@pytest.mark.asyncio
async def test_cleanup(integration_manager):
    """Test cleanup of integration resources"""
    await integration_manager.close()
    assert integration_manager.webui_session is None

def test_available_integrations(integration_manager):
    """Test getting available integrations"""
    integrations = integration_manager.get_available_integrations()
    
    assert isinstance(integrations, list)
    assert len(integrations) > 0
    assert IntegrationType.DEEPSEEK.value in integrations
    assert IntegrationType.OPENWEBUI.value in integrations
