import os
import json
import logging
import requests
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from enum import Enum

class PayloadSource(Enum):
    FUZZDB = "fuzzdb"
    PAYLOADSALLTHETHINGS = "payloadsallthethings"
    NOSQL = "nosql"
    CUSTOM = "custom"

@dataclass
class Payload:
    content: str
    source: str
    category: str
    description: Optional[str] = None

class PayloadManager:
    def __init__(self):
        self.logger = logging.getLogger("payload_manager")
        self._setup_logger()
        
        self.payloads: Dict[str, List[Payload]] = {
            PayloadSource.FUZZDB.value: [],
            PayloadSource.PAYLOADSALLTHETHINGS.value: [],
            PayloadSource.NOSQL.value: [],
            PayloadSource.CUSTOM.value: []
        }
        
        # GitHub raw content URLs
        self.sources = {
            PayloadSource.FUZZDB.value: {
                "base": "https://raw.githubusercontent.com/fuzzdb-project/fuzzdb/master/attack/sql-injection",
                "files": [
                    "detect/generic_sql.txt",
                    "detect/xplatform.txt",
                    "exploit/db2.txt",
                    "exploit/mysql.txt",
                    "exploit/mssql.txt",
                    "exploit/oracle.txt",
                    "exploit/postgres.txt"
                ]
            },
            PayloadSource.PAYLOADSALLTHETHINGS.value: {
                "base": "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/SQL%20Injection",
                "files": [
                    "Intruder/Auth_Bypass.txt",
                    "Intruder/Generic_SQL.txt",
                    "Intruder/MySQL.txt",
                    "Intruder/MSSQL.txt",
                    "Intruder/PostgreSQL.txt"
                ]
            },
            PayloadSource.NOSQL.value: {
                "base": "https://raw.githubusercontent.com/cr0hn/nosqlinjection_wordlists/master",
                "files": [
                    "mongodb_nosqli.txt",
                    "mongodb_operators.txt"
                ]
            }
        }
        
        self._load_payloads()

    def _setup_logger(self):
        """Configure logging"""
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
        self.logger.setLevel(logging.INFO)

    def _load_payloads(self):
        """Load payloads from all sources"""
        self.logger.info("Loading payloads from all sources...")
        
        # Load from online sources
        for source in PayloadSource:
            if source != PayloadSource.CUSTOM:
                self._load_from_source(source)
        
        # Load custom payloads
        self._load_custom_payloads()
        
        self.logger.info("Finished loading payloads")

    def _load_from_source(self, source: PayloadSource):
        """Load payloads from a specific online source"""
        if source.value not in self.sources:
            self.logger.warning(f"Source {source.value} not configured")
            return

        source_config = self.sources[source.value]
        base_url = source_config["base"]
        
        for file in source_config["files"]:
            try:
                url = f"{base_url}/{file}"
                response = requests.get(url, timeout=10)
                
                if response.status_code == 200:
                    category = os.path.splitext(os.path.basename(file))[0]
                    payloads = response.text.splitlines()
                    
                    for content in payloads:
                        if content.strip():  # Skip empty lines
                            self.payloads[source.value].append(
                                Payload(
                                    content=content.strip(),
                                    source=source.value,
                                    category=category
                                )
                            )
                    
                    self.logger.info(f"Loaded {len(payloads)} payloads from {url}")
                else:
                    self.logger.error(f"Failed to load payloads from {url}: {response.status_code}")
                    
            except Exception as e:
                self.logger.error(f"Error loading payloads from {url}: {str(e)}")

    def _load_custom_payloads(self):
        """Load custom payloads from local storage"""
        custom_path = os.path.join(os.path.dirname(__file__), "custom_payloads.json")
        
        try:
            if os.path.exists(custom_path):
                with open(custom_path, 'r') as f:
                    custom_data = json.load(f)
                    
                for item in custom_data:
                    self.payloads[PayloadSource.CUSTOM.value].append(
                        Payload(
                            content=item["content"],
                            source=PayloadSource.CUSTOM.value,
                            category=item.get("category", "custom"),
                            description=item.get("description")
                        )
                    )
                    
                self.logger.info(f"Loaded {len(custom_data)} custom payloads")
            else:
                self.logger.info("No custom payloads file found")
                
        except Exception as e:
            self.logger.error(f"Error loading custom payloads: {str(e)}")

    def add_custom_payload(self, content: str, category: str = "custom", description: str = None) -> bool:
        """Add a new custom payload"""
        try:
            payload = Payload(
                content=content,
                source=PayloadSource.CUSTOM.value,
                category=category,
                description=description
            )
            
            self.payloads[PayloadSource.CUSTOM.value].append(payload)
            self._save_custom_payloads()
            
            self.logger.info(f"Added new custom payload: {content}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error adding custom payload: {str(e)}")
            return False

    def _save_custom_payloads(self):
        """Save custom payloads to local storage"""
        custom_path = os.path.join(os.path.dirname(__file__), "custom_payloads.json")
        
        try:
            custom_data = [
                {
                    "content": p.content,
                    "category": p.category,
                    "description": p.description
                }
                for p in self.payloads[PayloadSource.CUSTOM.value]
            ]
            
            with open(custom_path, 'w') as f:
                json.dump(custom_data, f, indent=2)
                
            self.logger.info("Saved custom payloads")
            
        except Exception as e:
            self.logger.error(f"Error saving custom payloads: {str(e)}")

    def get_payloads(self, 
                     source: Optional[str] = None, 
                     category: Optional[str] = None) -> List[Payload]:
        """Get payloads filtered by source and/or category"""
        result = []
        
        # Determine which sources to include
        sources = [source] if source else [s.value for s in PayloadSource]
        
        for src in sources:
            if src in self.payloads:
                for payload in self.payloads[src]:
                    if not category or payload.category == category:
                        result.append(payload)
        
        return result

    def get_available_sources(self) -> List[str]:
        """Return list of available payload sources"""
        return [source.value for source in PayloadSource]

    def get_available_categories(self, source: Optional[str] = None) -> List[str]:
        """Return list of available payload categories"""
        categories = set()
        
        sources = [source] if source else [s.value for s in PayloadSource]
        
        for src in sources:
            if src in self.payloads:
                for payload in self.payloads[src]:
                    categories.add(payload.category)
        
        return list(categories)

    def search_payloads(self, query: str) -> List[Payload]:
        """Search payloads by content"""
        result = []
        
        for source_payloads in self.payloads.values():
            for payload in source_payloads:
                if query.lower() in payload.content.lower():
                    result.append(payload)
        
        return result
