"""Payload management and organization"""
