"""
MCP Server - Advanced Model Context Protocol server for vulnerability discovery
"""

__version__ = "1.0.0"
