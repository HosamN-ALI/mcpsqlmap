"""Core MCP server components"""
